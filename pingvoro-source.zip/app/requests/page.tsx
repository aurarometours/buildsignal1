import { desc,eq } from "drizzle-orm";
import { getDb } from "@/db";
import { accessRequests } from "@/db/schema";
import { requireChatGPTUser } from "../chatgpt-auth";
export const dynamic="force-dynamic";
export default async function Requests(){
 const user=await requireChatGPTUser("/requests");
 const rows=await getDb().select().from(accessRequests).where(eq(accessRequests.userId,user.userId)).orderBy(desc(accessRequests.createdAt)).limit(100);
 const labels:Record<string,string>={respond:"Responding to enquiries",qualify:"Qualification",appointments:"Appointment assistance",all:"The complete lead journey"};
 return <main className="legal-page"><a href="/">← back to pingvoro</a><h1>your requests.</h1><p>Early-access requests submitted from your signed-in account. These are requests for the programme, not activated subscriptions.</p>{rows.length===0?<><h2>nothing here yet.</h2><a className="text-link" href="/#contact">request early access →</a></>:rows.map(r=><article className="request-card" key={r.id}><small>{new Date(r.createdAt).toLocaleDateString("en-GB",{timeZone:"Europe/Rome"})} · saved</small><h2>{r.company}</h2><p>{r.name} · {r.email}</p><p>{labels[r.useCase]}</p>{r.message&&<p>{r.message}</p>}<p className="request-ref">reference · {r.id}</p></article>)}</main>
}

