import { z } from "zod";
import { and,eq,gte,count } from "drizzle-orm";
import { getDb } from "@/db";
import { accessRequests } from "@/db/schema";
import { getChatGPTUser } from "@/app/chatgpt-auth";
export const dynamic="force-dynamic";
const schema=z.object({requestId:z.string().uuid(),name:z.string().trim().min(2).max(100),email:z.string().trim().toLowerCase().email().max(254),company:z.string().trim().min(2).max(160),useCase:z.enum(["respond","qualify","appointments","all"]),message:z.string().trim().max(1500).default(""),consent:z.literal(true),website:z.string().max(0).optional()});
const json=(body:unknown,status=200)=>Response.json(body,{status,headers:{"Cache-Control":"no-store"}});
export async function POST(request:Request){
 const origin=request.headers.get("origin");if(origin&&origin!==new URL(request.url).origin)return json({error:"This request could not be verified. Reload the page and try again."},403);
 const user=await getChatGPTUser();if(!user)return json({error:"Please sign in to this private site before requesting access."},401);
 if(Number(request.headers.get("content-length")||0)>12000)return json({error:"Your request is too long."},413);
 let raw:string;try{raw=await request.text()}catch{return json({error:"The request could not be read."},400)}
 if(raw.length>12000)return json({error:"Your request is too long."},413);
 let input:unknown;try{input=JSON.parse(raw)}catch{return json({error:"Invalid request. Please try again."},400)}
 const parsed=schema.safeParse(input);if(!parsed.success)return json({error:"Please check your name, work email, company and consent. Name and company must have at least two characters."},400);
 try{const db=getDb(),data=parsed.data;
 const existing=await db.select({id:accessRequests.id,userId:accessRequests.userId}).from(accessRequests).where(eq(accessRequests.id,data.requestId)).get();
 if(existing)return existing.userId===user.userId?json({reference:existing.id}):json({error:"Please reload and submit again."},409);
 const total=await db.select({value:count()}).from(accessRequests).where(and(eq(accessRequests.userId,user.userId),gte(accessRequests.createdAt,Date.now()-3600000))).get();
 if((total?.value||0)>=5)return json({error:"You have already sent several requests. Please try again in an hour."},429);
 await db.insert(accessRequests).values({id:data.requestId,userId:user.userId,name:data.name,email:data.email,company:data.company,useCase:data.useCase,message:data.message,consentVersion:"early-access-2026-10-26",createdAt:Date.now()}).onConflictDoNothing();
 const saved=await db.select({userId:accessRequests.userId}).from(accessRequests).where(eq(accessRequests.id,data.requestId)).get();
 if(saved?.userId!==user.userId)return json({error:"Please reload and submit again."},409);
 return json({reference:data.requestId},201);
 }catch{return json({error:"We could not save your request. Your details are still in the form; please try again."},503)}
}

