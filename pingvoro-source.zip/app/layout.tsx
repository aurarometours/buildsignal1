import type { Metadata } from "next";
import "./globals.css";
export const metadata:Metadata={title:"Pingvoro — reply. qualify. connect.",description:"An AI assistant for inbound leads, in development. Explore the workflow and request early access.",metadataBase:new URL("https://pingvoro.aura-intravel.chatgpt.site"),icons:{icon:"/favicon.svg"},robots:{index:false,follow:false}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}

