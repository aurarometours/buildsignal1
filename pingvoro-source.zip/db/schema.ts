import { sqliteTable,text,integer,index } from "drizzle-orm/sqlite-core";
export const accessRequests=sqliteTable("access_requests",{id:text("id").primaryKey(),userId:text("user_id").notNull(),name:text("name").notNull(),email:text("email").notNull(),company:text("company").notNull(),useCase:text("use_case").notNull(),message:text("message").notNull().default(""),consentVersion:text("consent_version").notNull(),createdAt:integer("created_at").notNull()},table=>[index("requests_user_created").on(table.userId,table.createdAt)]);

